- Execute the following commands:

* pip install -r requirements.txt

* python fastslam.py